const http = require('http');
var queryString = require('querystring');

http.createServer((req,res)=>{
 // Write your own codes
});