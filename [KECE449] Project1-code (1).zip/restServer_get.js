const http = require('http');
const fs = require('fs');

http.createServer((req,res)=>{
 // Write your own codes
});